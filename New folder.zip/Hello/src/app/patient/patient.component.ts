import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {SharedServiceService} from '../shared-service.service';
import {Hospital} from '../Hospital';
import {Patient} from '../patient';
import { FormsModule } from '@angular/forms';
import { Alert } from 'selenium-webdriver';
@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {
 // hospital: Hospital[];
  private patient:Patient;
  private patients:Patient[];
  constructor(private router: Router, private sharedService: SharedServiceService) {

  }  
  //constructor(){}
  //
  //private user:User;
  //this.user=this._userService.getter();
  //Patient pati=new Patient();
  //private patient: Patient = new Patient();
  ngOnInit() 
  {
     //this.sharedService.getHospitals()
     this.patient=this.sharedService.getter();
  }

  createUser(patient)
  {
    this.sharedService.createPatient(patient).subscribe( data => {
      this.patients=data;
     
    })
  }
}
