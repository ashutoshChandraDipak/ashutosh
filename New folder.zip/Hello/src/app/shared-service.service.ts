import { Injectable } from '@angular/core';
import { HttpClientModule,HttpClient, HttpHeaders } from '@angular/common/http';
import { Hospital } from './Hospital';
import {Patient} from './Patient';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}
 

@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {
  patient:Patient;
  constructor(private http:HttpClient) {}
  private userUrl = 'http://localhost:8082/api/getHospitals';
  private userUrl1 = 'http://localhost:8082/api/getPatientsByHospitalId';
  
    public getHospitals()
    {
      return this.http.get<Hospital[]>(this.userUrl);
    }

    public deletePatient(id) {
      return this.http.delete('http://localhost:8082/api/deletePatients'+ "/"+ id);
    }

    public createPatient(patient) 
    {
      return this.http.post<Patient[]>('http://localhost:8082/api/createPatients', patient);
    }

    public getPatientById(hospital)
    {
      return this.http.get<Patient[]>(this.userUrl1+"/"+hospital.hospitalId);
    }
   /*  setter(user:User){
      this.user=user;
    } */
    public setter(patient:Patient)
    {
      this.patient=patient;
    }
    
  public  getter()
  {
    return this.patient;
  }
  

}
