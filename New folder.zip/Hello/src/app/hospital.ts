export class Hospital 
{
    hospitalId:number;
    Name:String;
    description:String;
    index:number;
}
