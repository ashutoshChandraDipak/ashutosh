import { TestBed } from '@angular/core/testing';

import { PatientmodelService } from './patientmodel.service';

describe('PatientmodelService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PatientmodelService = TestBed.get(PatientmodelService);
    expect(service).toBeTruthy();
  });
});
