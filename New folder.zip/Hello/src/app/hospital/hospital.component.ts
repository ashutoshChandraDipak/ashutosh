import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import {SharedServiceService} from '../shared-service.service';
import {Hospital} from '../Hospital';
import { FormsModule } from '@angular/forms';
import {Patient} from '../patient';

@Component({
  selector: 'app-hospital',
  templateUrl: './hospital.component.html',
  styleUrls: ['./hospital.component.css']
})
export class HospitalComponent implements OnInit {

   flag:Boolean=false;
   temp:number;
   buttonName : any = 'ShowPatients';
   show:boolean = false;
   hospital1:number;
   visibleRowIndex:number=null;
  
  hospitals: Hospital[];
  hospital: Hospital[];
  patients:Patient[];
  patien:Patient;

  constructor(private sharedService: SharedServiceService,private router:Router) {

  } 
   //let Boolean:flag=false;

  ngOnInit() {
    this.sharedService.getHospitals()
      .subscribe( data => {
        this.hospitals = data;
         
        console.log(this.hospitals);
        //alert(this.hospitals);
      });
  };
    getHidePatient(index)
    {
      this.flag=false;
    }
    
    deletePatient(patient): void 
    {
      alert(patient.id)
    this.sharedService.deletePatient(patient.id)
      .subscribe( data => {
        this.patients = this.patients.filter(u => u !== patient);
      })
  }; 

    updatePatient(patients)
    {
      this.sharedService.setter(patients);
      //this.router.navigate(['/patient']);
      this.router.navigate(['patient']);
    }


  


}
