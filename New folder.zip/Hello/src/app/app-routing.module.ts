import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {UserRegistrationComponent} from './user-registration/user-registration.component';
import {UserloginComponent} from './userlogin/userlogin.component';
import {HospitalComponent} from './hospital/hospital.component';
import {PatientComponent} from './patient/patient.component';
import {PatientFormComponent} from './patient-form/patient-form.component';

const routes: Routes = [
  {path:'registration',component:UserRegistrationComponent},
  {path:'',component:HospitalComponent},
  {path:'hospital',component:UserloginComponent},
  {path:'patient',component:PatientComponent},
  {path:'patientForm',component:PatientFormComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
