export class Patient 
{
     id:number;
     Name:String;
     dateOfBirth:Date;
     gender:String;
     hospitalId:number;
     age:number;
}